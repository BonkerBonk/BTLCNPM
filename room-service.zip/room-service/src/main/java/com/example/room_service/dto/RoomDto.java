package com.example.room_service.dto;

import lombok.Data;

@Data
public class RoomDto {
    private String name;
    private int capacity;
    private String theaterId;
}
